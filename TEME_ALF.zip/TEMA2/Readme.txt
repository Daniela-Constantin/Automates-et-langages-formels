In vederea realizarii acestei teme am indeplinit urmatoarele:

-Pasul 1: Pregatirea terenului
	Am citit din terminal cu process.argv parametrii corespunzatori fisierelor de input si output;
	Mi-am setat pozitia initiala a "creionului" in (0,0), precum si culoarea acestuia (initial rgb(0,0,0)) si cea de fundal (initial rgb(255,255,255));
	Am creat un vector pentru variabile. Acesta va fi umplut pe parcursul programului de obiecte care retin numele variabilelor si valorile lor;
	Am creat o variabila "de_afisat" in care voi retine textul pe care il voi afisa in fisierul de output;
	Am citit din fisier si am stocat input-ul in variabila "data";
	Am impartiti continutul fisierului pe linii cu ajutorul functiei split("\n"), rezultatul fiind un vector cu toate liniile citite.
 
-Pasul 2: Parcurgerea fisierului si identificarea comenzilor
	Am parcurs cu un for vectorul de linii;
	Am observat ca toate comenzile posibile contin separatorul ":" si ca sunt de forma "Numele_operatiei : param1 param2 ...";
	Daca gaseam separatorul ":" pe linia curenta, faceam split dupa acesta, ceea ce imi crea un vector care continea pe prima pozitie numele comenzii
	de executat si pe urmatoarele parametrii aferenti acesteia;
	In variabila "op" am salvat asadar operatia/statementul, avand grija sa elimin toate spatiile de prisos (trim);
	In vectorul "param" am stocat parametrii dupa ce am scos toate spatiile (aici am fost nevoita sa regurg la un split dupa regex-ul /s+/, dat
	fiind faptul ca aveam de a face cu un numar necunoscut de spatii);
	Am continuat apoi cu identificarea operatiei curente, iar odata gasita, am apelat functia corespunzatoare acesteia;
	Am ales sa creez functii pentru a face codul mai lizibil, dar in special pentru a evita rescierea unor mari portiuni de mai multe ori (exemplu: 
	loop-urile care contin mai multe statementuri);
	La toate functiile am transmis ca parametrii linia pe care se gaseste functia si vectorul de parametrii;
	Comenzile FOR si WHILE nu dispun de functii pentru ca nu le apelez de mai multe ori.

-Pasul 3: Functiile pentru statementuri
	In cadrul fiecarei functii, am tratat mai intai cazurile de eroare (daca nu am destui parametrii, daca parametrii nu sunt de tipul cerut-numar sau variabila- etc.);
	Daca nu am erori, in functie de operatie, continui sa scriu in "de_afisat" textul svg corespunzator.

-Pasul 4: Finalizare
	La final, adaug in "de_afisat" </svg>, care indica terminarea programului;
	Afisez in fisierul de output textul "de_afisat". 
	 