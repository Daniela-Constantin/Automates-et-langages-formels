"use strict";

var fisierint = process.argv[2];
var fisierout = process.argv[3];
var pozx = 0;
var pozy = 0;
var pen_col = "rgb(0,0,0)";
var fill_col = "rgb(255,255,255)";
var variabile = []; //VECTORUL DE VARIABILE
var de_afisat = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>" +"\n" +"<svg width=\"1024\" height=\"768\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">";  

var fs = require('fs');

try {
    var data = fs.readFileSync(fisierint).toString(); //CITIREA DIN DESIGN.DSN
} catch(err) {
   console.error(err);
}

function INIT(param,i) 
{
    var ob;
    var deja_init = -1;
    var retin_poz = -1;
    var p1 = parseInt(param[1]);

    if(param.length!=2) 
        console.log("LINE " + parseInt(i+1) + " HAS ERROR: INIT needs 2 parameters, you wrote " + param.length);
    else 
    {
        if(param[0].indexOf("$")!==0)
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: INIT parameter 1 needs to be a variable, you wrote " + param[0]);
                
        if(!isNaN(param[1]) && param[0].indexOf("$")===0) //DACA AL DOILEA PARAM E NUMAR
        {
            for(let k=0;k<variabile.length; k++) //VERIFIC DACA NU CUMVA E DEJA INITIALIZATA VAR CU NUMELE ASTA
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    deja_init = k;
                    break;
                }
            }
            if(deja_init!=-1)
            {
                variabile[deja_init].value = param[1];
            }
            else
            {
                ob = {name: param[0].substring(1), value: p1};
                variabile.push(ob);
            }
        }
                    
        if(param[1].indexOf("$") === 0 && param[0].indexOf("$") === 0) //DACA AL DOILEA PARAM E VAR
        {
            for(let k=0; k<variabile.length; k++)
            {
                if(variabile[k].name == param[1].substring(1))
                {
                    retin_poz = k;
                    break;
                }
            if(k == variabile.length+1)    
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: INIT parameter 2 needs to be a number or a variable, you wrote " + param[1]);
            }
            for(let j=0;j<variabile.length; j++) //VERIFIC DACA NU CUMVA E DEJA INITIALIZATA VAR CU NUMELE ASTA
            {
                if(variabile[j].name == param[0].substring(1))
                {
                    deja_init = j;
                    break;
                }
            }
            if(deja_init!=-1)
            {
                variabile[deja_init].value = variabile[retin_poz].value;
            }
            else
            {
                ob = {name: param[0].substring(1), value: variabile[retin_poz].value};
                variabile.push(ob);
            }
        }
                
        if(isNaN(p1) && param[1].indexOf("$") !== 0) //DACA AL DOILEA PARAM NU E NICI NUMAR NICI VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: INIT parameter 2 needs to be a number or a variable, you wrote " + param[1]);
        }
    }
}

function SET_COLOR(param,i)
{
    var ok,r,g,b;
    if(param.length == 4)
            {
                if(param[3]=='pen')
                {
                    r=parseInt(param[0]);
                    g=parseInt(param[1]);
                    b=parseInt(param[2]);
                    if(isNaN(r) && param[0].indexOf("$") !== 0) //DACA PARAM PT ROSU NU E NICI NR NICI VAR
                        console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +1+ " needs to be a number or a variable, you wrote " + param[0]);
                    if(isNaN(g) && param[1].indexOf("$") !== 0) //DACA PARAM PT VERDE NU E NICI NR NICI VAR
                        console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +2+ " needs to be a number or a variable, you wrote " + param[1]);
                    if(isNaN(b) && param[2].indexOf("$") !== 0) //DACA PARAM PT ALBASTRU NU E NICI NR NICI VAR
                        console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +3+ " needs to be a number or a variable, you wrote " + param[2]);
                    if(param[0].indexOf("$") === 0) //DACA ROSU E VAR
                    {
                        ok = 0;
                        for(let k=0;k<variabile.length; k++)
                        {
                            if(variabile[k].name == param[0].substring(1))
                            {
                                param[0]=variabile[k].value;
                                ok=1;
                                break;
                            }
                        }
                        if(ok===0)
                        {
                            console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +1+ " needs to be a number or a variable, you wrote " + param[0]);
                        }
                    }
                    if(param[1].indexOf("$") === 0) //DACA VERDE E VAR
                    {
                        ok = 0;
                        for(let k=0;k<variabile.length; k++)
                        {
                            if(variabile[k].name == param[1].substring(1))
                            {
                                param[1]=variabile[k].value;
                                ok=1;
                                break;
                            }
                        }
                        if(ok===0)
                        {
                            console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +2+ " needs to be a number or a variable, you wrote " + param[1]);
                        }
                    }
                    if(param[2].indexOf("$") === 0) //DACA ALBASTRU E VAR
                    {
                        ok = 0;
                        for(let k=0;k<variabile.length; k++)
                        {
                            if(variabile[k].name == param[2].substring(1))
                            {
                                param[2]=variabile[k].value;
                                ok=1;
                                break;
                            }
                        }
                        if(ok===0)
                        {
                            console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +3+ " needs to be a number or a variable, you wrote " + param[2]);
                        }
                    }
                    if(!isNaN(param[0])&& (param[0]<0 || param[0]>255))
                    {
                        console.log("LINE "+ parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter "+1+" needs to be a number or a variable between [0, 255], you wrote "+ param[0]);
                    }
                    if(!isNaN(param[1])&& (param[1]<0 || param[1]>255))
                    {
                        console.log("LINE "+ parseInt(i+1) + " HAS ERROR: SET_COLOR parameter "+2+" needs to be a number or a variable between [0, 255], you wrote "+ param[1]);
                    }
                    if(!isNaN(param[2])&& (param[2]<0 || param[2]>255))
                    {
                        console.log("LINE "+ parseInt(i+1) + " HAS ERROR: SET_COLOR parameter "+3+" needs to be a number or a variable between [0, 255], you wrote "+ param[2]);
                    }
                    if(!isNaN(param[0]) && param[0]>=0 && param[0]<=255 && !isNaN(param[1]) && param[1]>=0 && param[1]<=255&& !isNaN(param[2]) && param[2]>=0 && param[2]<=255)
                    {
                        pen_col = "rgb(" +param[0]+","+param[1]+","+param[2]+")";
                    }
                }
                if(param[3]=='fill')
                {
                    r=parseInt(param[0]);
                    g=parseInt(param[1]);
                    b=parseInt(param[2]);
                    if(isNaN(r) && param[0].indexOf("$") !== 0) //DACA PARAM PT ROSU NU E NICI NR NICI VAR
                        console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +1+ " needs to be a number or a variable, you wrote " + param[0]);
                    if(isNaN(g) && param[1].indexOf("$") !== 0) //DACA PARAM PT VERDE NU E NICI NR NICI VAR
                        console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +2+ " needs to be a number or a variable, you wrote " + param[1]);
                    if(isNaN(b) && param[2].indexOf("$") !== 0) //DACA PARAM PT ALBASTRU NU E NICI NR NICI VAR
                        console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +3+ " needs to be a number or a variable, you wrote " + param[2]);
                    if(param[0].indexOf("$") === 0)
                    {
                        ok = 0;
                        for(let k=0;k<variabile.length; k++)
                        {
                            if(variabile[k].name == param[0].substring(1))
                            {
                                param[0]=variabile[k].value;
                                ok=1;
                                break;
                            }
                        }
                        if(ok===0)
                        {
                            console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +1+ " needs to be a number or a variable, you wrote " + param[0]);
                        }
                    }
                    if(param[1].indexOf("$") === 0)
                    {
                        ok = 0;
                        for(let k=0;k<variabile.length; k++)
                        {
                            if(variabile[k].name == param[1].substring(1))
                            {
                                param[1]=variabile[k].value;
                                ok=1;
                                break;
                            }
                        }
                        if(ok===0)
                        {
                            console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +2+ " needs to be a number or a variable, you wrote " + param[1]);
                        }
                    }
                    if(param[2].indexOf("$") === 0)
                    {
                        ok = 0;
                        for(let k=0;k<variabile.length; k++)
                        {
                            if(variabile[k].name == param[2].substring(1))
                            {
                                param[2]=variabile[k].value;
                                ok=1;
                                break;
                            }
                        }
                        if(ok===0)
                        {
                            console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter " +3+ " needs to be a number or a variable, you wrote " + param[2]);
                        }
                    }
                    if(!isNaN(param[0])&& (param[0]<0 || param[0]>255))
                    {
                        console.log("LINE "+ parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter "+1+" needs to be a number or a variable between [0, 255], you wrote "+ param[0]);
                    }
                    if(!isNaN(param[1])&& (param[1]<0 || param[1]>255))
                    {
                        console.log("LINE "+ parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter "+2+" needs to be a number or a variable between [0, 255], you wrote "+ param[1]);
                    }
                    if(!isNaN(param[2])&& (param[2]<0 || param[2]>255))
                    {
                        console.log("LINE "+ parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter "+3+" needs to be a number or a variable between [0, 255], you wrote "+ param[2]);
                    }
                    if(!isNaN(param[0]) && param[0]>=0 && param[0]<=255 && !isNaN(param[1]) && param[1]>=0 && param[1]<=255&& !isNaN(param[2]) && param[2]>=0 && param[2]<=255)
                    {
                        fill_col = "rgb(" +param[0]+","+param[1]+","+param[2]+")";
                    
                    }
                }
                if(param[3]!='fill' && param[3]!='pen')
                    console.log("LINE " +parseInt(i+1)+ " HAS ERROR: SET_COLOR parameter 4 needs to be one of (pen, fill), you wrote " + param[3]);
            }
            else 
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: SET_COLOR uses 4 parameters, you wrote " + param.length);
}

function LOCATION(param,i)
{
    var ok;
    if(param.length!=2) 
        console.log("LINE " + parseInt(i+1) + " HAS ERROR: LOCATION needs 2 parameters, you wrote " + param.length);
    else 
    {
        ok = 1;
        for(let j=0; j<param.length; j++)
        {
            if(param[j].indexOf("$") === 0)
            {
                var p = param[j].substring(1);
                for(let k=0; k<variabile.length; k++)
                {
                    if(variabile[k].name == p && variabile[k].value == 'undefined')
                    {
                        console.log("LINE " + parseInt(i+1) + " HAS ERROR: LOCATION parameter " + j + " needs to be a variable or a number, you wrote " + param[j]);
                        ok = 0;
                    }
                    if(variabile[k].name == p && variabile[k].value != 'undefined')
                        param[j] = variabile[k].value;
                }
            }
        }
    }
    if(ok == 1)
    {
        pozx = param[0];
        pozy = param[1];
    }
}

function DRAW_LINE(param,i)
{
    var ok;
    if(param.length==3)
    {
        var p1=parseInt(param[0]);
        var p2=parseInt(param[1]);
        var p3=parseInt(param[2]);

        if(isNaN(p1) && param[0].indexOf("$")!==0) //DACA PRIMUL PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_LINE parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
        }
        if(isNaN(p2) && param[1].indexOf("$")!==0) //DACA AL DOILEA PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_LINE parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(param[0].indexOf("$")===0) //DACA PRIMUL E VAR 
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    param[0]=variabile[k].value;
                    ok = 1;
                    break;
                }
            }    
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_LINE parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
            }
        }
        if(param[1].indexOf("$")===0) //DACA AL DOILEA E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[1].substring(1))
                {
                    param[1]=variabile[k].value;
                    ok = 1;
                    break;
                }
            }    
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_LINE parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(!isNaN(param[0]) && !isNaN(param[1]) && (param[2]=='polar' || param[2]=='location'))
        {
            if(param[2]=='location')
            {
                de_afisat += "\n" + "<line x1=\"" + pozx + "\" y1=\"" + pozy + "\" x2=\""+ param[0] + "\" y2=\"" + param[1] + "\" stroke-width=\"1\" stroke=\""+ pen_col +"\"/>";    
                pozx=param[0];
                pozy=param[1];
            }
            else if(param[2]=='polar')
            {
                var lungime = parseFloat(param[0]);
                var unghi = parseFloat(param[1]*Math.PI/180);
                var noulx=parseFloat(pozx)+Math.cos(unghi)*lungime;
                var nouly=parseFloat(pozy)-(Math.sin(unghi))*lungime;
                de_afisat += "\n" + "<line x1=\"" + pozx + "\" y1=\"" + pozy + "\" x2=\""+ noulx + "\" y2=\"" + nouly + "\" stroke-width=\"1\" stroke=\""+ pen_col +"\"/>"; 
                pozx=parseFloat(pozx)+Math.cos(unghi)*lungime;
                pozy=parseFloat(pozy)-(Math.sin(unghi))*lungime;
            }
        }
        if(param[2]!= 'location' && param[2]!='polar') //DACA NU SE TERMINA IN POLAR SAU LOCATION 
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_LINE parameter 3 needs to be one of (location, polar), you wrote " + param[2]);
        }
    }
    else //DACA NU AM FIX 3 PARAMETRII
    {
        console.log("LINE" + parseInt(i+1) + " HAS ERROR: DRAW_LINE command needs 3 parameters, you wrote " + param.length);
    }
}

function DRAW_CIRCLE(param,i)
{
    var ok;
    if(param.length==3)
    {
        var p1 = parseInt(param[0]);
        var p2 = parseInt(param[1]);
        var p3 = parseInt(param[2]);
        if(isNaN(p1) && param[0].indexOf("$")!==0) //DACA PRIMUL PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_CIRCLE parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
        }
        if(isNaN(p2) && param[1].indexOf("$")!==0) //DACA AL DOILEA PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_CIRCLE parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(isNaN(p3) && param[2].indexOf("$")!==0) //DACA AL TREILEA PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_CIRCLE parameter " + 3 + " needs to be a number or a variable, you wrote " + param[2]);
        }
        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    param[0]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_CIRCLE parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
            }
        }
        if(param[1].indexOf("$")===0) //AL DOILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[1].substring(1))
                {
                    ok = 1;
                    param[1]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_CIRCLE parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(param[2].indexOf("$")===0) //AL TREILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[2].substring(1))
                {
                    ok = 1;
                    param[2]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_CIRCLE parameter " + 3 + " needs to be a number or a variable, you wrote " + param[2]);
            }
        }
        if(!isNaN(param[0]) && !isNaN(param[1]) && !isNaN(param[2])) //DACA TOTI 3 PARAM SUNT NUMERE
        {
            de_afisat += "\n" + "<circle cx=\"" + param[1] + "\" cy=\"" + param[2] + "\" r=\""+ param[0] + "\" stroke-width=\"1\" stroke=\""+ pen_col +"\" fill=\""+  fill_col +"\"/>";   
        }    
    }
    else 
    {
        console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_CIRCLE command needs 3 parameters, you wrote " + param.length);
    }
}

function DRAW_ELLIPSE(param,i)
{
    var ok;
    if(param.length==4)
    {
        var p1 = parseInt(param[0]);
        var p2 = parseInt(param[1]);
        var p3 = parseInt(param[2]);
        var p4 = parseInt(param[3]);
        if(isNaN(p1) && param[0].indexOf("$")!==0) //DACA PRIMUL PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
        }
        if(isNaN(p2) && param[1].indexOf("$")!==0) //DACA AL DOILEA PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(isNaN(p3) && param[2].indexOf("$")!==0) //DACA AL TREILEA PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 3 + " needs to be a number or a variable, you wrote " + param[2]);
        }
        if(isNaN(p4) && param[3].indexOf("$")!==0) //DACA AL PATRULEA PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 4 + " needs to be a number or a variable, you wrote " + param[3]);
        }
        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    param[0]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
            }
        }
        if(param[1].indexOf("$")===0) //AL DOILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[1].substring(1))
                {
                    ok = 1;
                    param[1]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(param[2].indexOf("$")===0) //AL TREILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[2].substring(1))
                {
                    ok = 1;
                    param[2]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 3 + " needs to be a number or a variable, you wrote " + param[2]);
            }
        }
        if(param[3].indexOf("$")===0) //AL PATRULEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[3].substring(1))
                {
                    ok = 1;
                    param[3]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 4 + " needs to be a number or a variable, you wrote " + param[3]);
            }
        }
        if(!isNaN(param[0]) && !isNaN(param[1]) && !isNaN(param[2]) && !isNaN(param[3])) //DACA TOTI 4 PARAM SUNT NUMERE
        {
            de_afisat += "\n" + "<ellipse cx=\"" + param[2] + "\" cy=\"" + param[3] + "\" rx=\""+ param[0] + "\" ry=\""+ param[1] +"\" stroke-width=\"1\" stroke=\""+ pen_col +"\" fill=\""+  fill_col +"\"/>";   
        }    
    }
    else 
    {
        console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE needs 4 parameters, you wrote " + param.length);
    }
}

function DRAW_RECTANGLE(param,i)
{
    var ok;
    if(param.length==4)
    {
        var p1 = parseInt(param[0]);
        var p2 = parseInt(param[1]);
        var p3 = parseInt(param[2]);
        var p4 = parseInt(param[3]);
        if(isNaN(p1) && param[0].indexOf("$")!==0) //DACA PRIMUL PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
        }
        if(isNaN(p2) && param[1].indexOf("$")!==0) //DACA AL DOILEA PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(isNaN(p3) && param[2].indexOf("$")!==0) //DACA AL TREILEA PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 3 + " needs to be a number or a variable, you wrote " + param[2]);
        }
        if(isNaN(p4) && param[3].indexOf("$")!==0) //DACA AL PATRULEA PARAMETRU NU ESTE NICI UN NUMAR NICI O VARIABILA
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_ELLIPSE parameter " + 4 + " needs to be a number or a variable, you wrote " + param[3]);
        }
        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    param[0]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_RECTANGLE parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
            }
        }
        if(param[1].indexOf("$")===0) //AL DOILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[1].substring(1))
                {
                    ok = 1;
                    param[1]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_RECTANGLE parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(param[2].indexOf("$")===0) //AL TREILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[2].substring(1))
                {
                    ok = 1;
                    param[2]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_RECTANGLE parameter " + 3 + " needs to be a number or a variable, you wrote " + param[2]);
            }
        }
        if(param[3].indexOf("$")===0) //AL PATRULEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[3].substring(1))
                {
                    ok = 1;
                    param[3]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DRAW_RECTANGLE parameter " + 4 + " needs to be a number or a variable, you wrote " + param[3]);
            }
        }
        if(!isNaN(param[0]) && !isNaN(param[1]) && !isNaN(param[2]) && !isNaN(param[3])) //DACA TOTI 4 PARAM SUNT NUMERE
        {
            de_afisat += "\n" + "<polygon points=\""+param[0]+","+param[1]+" "+param[2]+","+param[1]+" "+param[2]+","+param[3]+" "+param[0]+","+param[3]+"\" stroke-width=\"1\" stroke=\""+ pen_col +"\" fill=\""+  fill_col +"\"/>";   
        }    
    }
    else 
    {
        console.log("LINE" + parseInt(i+1) + " HAS ERROR: DRAW_RECTANGLE command needs 3 parameters, you wrote " + param.length);
    }
}

function ADDITION(param,i)
{
    var ok,poz_var;
    if(param.length==2)
    {
        if(param[0].indexOf("$")!==0) //DACA PRIMUL PARAM NU E VAR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: ADDITION parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
        }
        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            ok = 0;
            poz_var=-1;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    poz_var = k;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: ADDITION parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
            }
        }
        if(isNaN(param[1])&&param[0].indexOf("$")!==0) //DACA AL DOILEA PARAM NU E NICI VAR NICI NR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: ADDITION parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(param[1].indexOf("$")===0) //AL DOILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[3].substring(1))
                {
                    ok = 1;
                    param[1]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: ADDITION parameter " + 1 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(poz_var!=-1 && !isNaN(param[1]))
        {
            variabile[poz_var].value= parseFloat(variabile[poz_var].value)+parseFloat(param[1]);
        }
    }
    else
    {
        console.log("LINE" + parseInt(i+1) + " HAS ERROR: ADDITION command needs 2 parameters, you wrote " + param.length);
    }
}

function SUBTRACTION(param,i)
{
    var ok,poz_var;
    if(param.length==2)
    {
        if(param[0].indexOf("$")!==0) //DACA PRIMUL PARAM NU E VAR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: SUBTRACTION parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
        }
        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            ok = 0;
            poz_var=-1;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    poz_var = k;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: SUBTRACTION parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
            }
        }
        if(isNaN(param[1])&&param[0].indexOf("$")!==0) //DACA AL DOILEA PARAM NU E NICI VAR NICI NR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: SUBTRACTION parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(param[1].indexOf("$")===0) //AL DOILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[3].substring(1))
                {
                    ok = 1;
                    param[1]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: SUBTRACTION parameter " + 1 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(poz_var!=-1 && !isNaN(param[1]))
        {
            variabile[poz_var].value= parseFloat(variabile[poz_var].value)-parseFloat(param[1]);
        }
    }
    else
    {
        console.log("LINE" + parseInt(i+1) + " HAS ERROR: SUBTRACTION command needs 2 parameters, you wrote " + param.length);
    }
}

function MULTIPLY(param,i)
{
    var ok,poz_var;
    if(param.length==2)
    {
        if(param[0].indexOf("$")!==0) //DACA PRIMUL PARAM NU E VAR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: MULTIPLY parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
        }
        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            ok = 0;
            poz_var=-1;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    poz_var = k;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: MULTIPLY parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
            }
        }
        if(isNaN(param[1])&&param[0].indexOf("$")!==0) //DACA AL DOILEA PARAM NU E NICI VAR NICI NR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: MULTIPLY parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(param[1].indexOf("$")===0) //AL DOILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[3].substring(1))
                {
                    ok = 1;
                    param[1]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: MULTIPLY parameter " + 1 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(poz_var!=-1 && !isNaN(param[1]))
        {
            variabile[poz_var].value= parseFloat(variabile[poz_var].value)*parseFloat(param[1]);
        }
    }
    else
    {
        console.log("LINE" + parseInt(i+1) + " HAS ERROR: MULTIPLY command needs 2 parameters, you wrote " + param.length);
    }
}

function DIVISION(param,i)
{
    var ok,poz_var;
    if(param.length==2)
    {
        if(param[0].indexOf("$")!==0) //DACA PRIMUL PARAM NU E VAR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DIVISION parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
        }
        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            ok = 0;
            poz_var=-1;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    poz_var = k;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DIVISION parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
            }
        }
        if(isNaN(param[1])&&param[0].indexOf("$")!==0) //DACA AL DOILEA PARAM NU E NICI VAR NICI NR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: DIVISION parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(param[1].indexOf("$")===0) //AL DOILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[3].substring(1))
                {
                    ok = 1;
                    param[1]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: DIVISION parameter " + 1 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(poz_var!=-1 && !isNaN(param[1]))
        {
            variabile[poz_var].value= parseFloat(variabile[poz_var].value)/parseFloat(param[1]);
        }
    }
    else
    {
        console.log("LINE" + parseInt(i+1) + " HAS ERROR: DIVISION command needs 2 parameters, you wrote " + param.length);
    }
}

function IDIVISION(param,i)
{
    var ok,poz_var;
    if(param.length==2)
    {
        if(param[0].indexOf("$")!==0) //DACA PRIMUL PARAM NU E VAR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: IDIVISION parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
        }
        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            ok = 0;
            poz_var=-1;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    poz_var = k;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: IDIVISION parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
            }
        }
        if(isNaN(param[1])&&param[1].indexOf("$")!==0) //DACA AL DOILEA PARAM NU E NICI VAR NICI NR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: IDIVISION parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(param[1].indexOf("$")===0) //AL DOILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[1].substring(1))
                {
                    ok = 1;
                    param[1]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: IDIVISION parameter " + 1 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(poz_var!=-1 && !isNaN(param[1]))
        {
            variabile[poz_var].value= parseInt(parseFloat(variabile[poz_var].value)/parseFloat(param[1]));
        }
    }
    else
    {
        console.log("LINE" + parseInt(i+1) + " HAS ERROR: IDIVISION command needs 2 parameters, you wrote " + param.length);
    }
}

function MODULO(param,i)
{
    var ok,poz_var;
    if(param.length==2)
    {
        if(param[0].indexOf("$")!==0) //DACA PRIMUL PARAM NU E VAR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: MODULO parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
        }
        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            ok = 0;
            poz_var=-1;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    poz_var = k;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: MODULO parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
            }
        }
        if(isNaN(param[1])&&param[1].indexOf("$")!==0) //DACA AL DOILEA PARAM NU E NICI VAR NICI NR
        {
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: MODULO parameter " + 2 + " needs to be a number or a variable, you wrote " + param[1]);
        }
        if(param[1].indexOf("$")===0) //AL DOILEA PARAM E VAR
        {
            ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[1].substring(1))
                {
                    ok = 1;
                    param[1]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: MODULO parameter " + 1 + " needs to be a number or a variable, you wrote " + param[1]);
            }
        }
        if(poz_var!=-1 && !isNaN(param[1]))
        {
            variabile[poz_var].value = variabile[poz_var].value % param[1];
        }
    }
    else
    {
        console.log("LINE" + parseInt(i+1) + " HAS ERROR: MODULO command needs 2 parameters, you wrote " + param.length);
    }
}

function IF(param,i)
{
    var poz;
    if(param.length!=1) //DACA NU AM FIX UN PARAM
    {
        console.log("LINE " + parseInt(i+1) + " HAS ERROR: IF needs 1 parameters, you wrote " + param.length);
        //var verif = 1; //CHIAR SI CU MAI MULTI PARAM SE EXECUTA FOR-UL DE (primul param) ORI
    }
    if(param.length > 0) //DACA AM CEL PUTIN UN PARAM
    {
        if(param[0].indexOf("$")!==0) //DACA PRIMUL PARAM NU E VAR 
        {
            //verif = 1;
            console.log("LINE " + parseInt(i+1) + " HAS ERROR: IF parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
        }

        if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
        {
            var ok = 0;
            for(let k=0;k<variabile.length; k++)
            {
                if(variabile[k].name == param[0].substring(1))
                {
                    ok = 1;
                    poz=k;
                    param[0]=variabile[k].value;
                    break;
                }
            }
            if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: IF parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
            }
        }

        var nr_if = 1;
        var nr_end = 0;
        var nr_else = 0;
        if(poz>=0 && variabile[poz].value>0) //DACA S A GASIT VARIABILA SI E DIFERITA DE 0
        {
            while(nr_if!=nr_end && i<linii.length && nr_else===0)
            {
                i++;
                if(i<linii.length && linii[i].toLowerCase().indexOf('if')>=0 ) 
                    nr_if++;
                if(i<linii.length && linii[i].toLowerCase().indexOf('end')>=0 ) 
                    nr_end++;
                if(linii[i].toLowerCase().indexOf("else") >= 0) //DACA AM DAT DE UN ELSE
                    nr_else++;

                if(i<linii.length && linii[i].indexOf(":")>0) //DACA AM UN STATEMENT
                {
                    var l = linii[i].split(":"); //SEPARA CUVINTELE DE PE LINII DUPA :
                    var op = l[0].trim(l[0]); //STOCHEAZA IN OP OPERATIA CURENTA
                    l[1] = l[1].trim(l[1]);
                    var param_altfel = l[1].split(/\s+/); //SEPARA LINIA (DEJA SEPARATA DUPA :) DUPA SPATIU

                    if(op.toLowerCase().indexOf("init")===0)
                    {
                        INIT(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("set_color")===0)
                    {
                        SET_COLOR(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("location")===0)
                    {
                        LOCATION(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("draw_line")===0) 
                    {   
                        DRAW_LINE(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("draw_circle")===0) 
                    {
                        DRAW_CIRCLE(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("draw_ellipse")===0)  
                    { 
                        DRAW_ELLIPSE(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("draw_rectangle")===0)    
                    {
                        DRAW_RECTANGLE(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("addition")===0)  
                    {  
                        ADDITION(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("subtraction")===0)  
                    {  
                        SUBTRACTION(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("multiply")===0) 
                    {   
                        MULTIPLY(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("division")===0)  
                    {  
                        DIVISION(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("idivision")===0) 
                    {  
                        IDIVISION(param_altfel,i);
                    }
                    if(op.toLowerCase().indexOf("modulo")===0)   
                    {
                        MODULO(param_altfel,i);
                    }
                }
            }
            if(i==linii.length)
            {
                console.log("You have "+ parseInt(nr_if-nr_end) + " IF without END");
            }
            if(nr_else == 1) //DACA AM DAT DE ELSE DAR S A VERIFICAT CONDITIA LUI IF
            {
                while(nr_if!=nr_end && i<linii.length)
                {
                    i++; //SAR PESTE LINII PANA LA SF FISIERULUI SAU PANA LA END
                    if(i<linii.length && linii[i].toLowerCase().indexOf('end')>=0 ) 
                        nr_end++;
                }
                if(i==linii.length) //DACA AM AJUNS LA SF FISIERULUI SI N AM DAT DE END
                    console.log("You have "+ parseInt(nr_if-nr_end) + " IF without END");
            }
        }
        if(poz>=0 &&variabile[poz].value===0) //DACA S A GASIT VAR SI E EGALA CU 0
        {
            while(nr_else===0 && nr_if!=nr_end && i<linii.length) //TOT SAR PESTE LINII PANA DAU DE ELSE SAU DE END 
            {
                i++;
                if(linii[i].toLowerCase().indexOf("else") >= 0)
                    nr_else++;
                if(i<linii.length && linii[i].toLowerCase().indexOf('end')>=0 ) 
                    nr_end++;
            }
            if(nr_else!==0 && linii[i].toLowerCase().indexOf("else") >= 0) //DACA AM DAT DE ELSE
            {
                while(i<linii.length && nr_if!=nr_end) //EXECUT PANA DAU DE END SAU DE SF FISIERULUI
                {
                    i++;
                    if(i<linii.length && linii[i].toLowerCase().indexOf('end')>=0 ) 
                    {
                        nr_end++;
                    }
                    if(i<linii.length && linii[i].indexOf(":")>0) //DACA AM UN STATEMENT
                    {
                        var li = linii[i].split(":"); //SEPARA CUVINTELE DE PE LINII DUPA :
                        var ope = li[0].trim(li[0]); //STOCHEAZA IN OP OPERATIA CURENTA
                        li[1] = li[1].trim(li[1]);
                        var param_altfel_bis = li[1].split(/\s+/); //SEPARA LINIA (DEJA SEPARATA DUPA :) DUPA SPATIU

                        if(ope.toLowerCase().indexOf("init")===0)
                        {
                            INIT(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("set_color")===0)
                        {
                            SET_COLOR(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("location")===0)
                        {
                            LOCATION(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("draw_line")===0) 
                        {   
                            DRAW_LINE(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("draw_circle")===0) 
                        {
                            DRAW_CIRCLE(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("draw_ellipse")===0)  
                        { 
                            DRAW_ELLIPSE(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("draw_rectangle")===0)    
                        {
                            DRAW_RECTANGLE(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("addition")===0)  
                        {  
                            ADDITION(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("subtraction")===0)  
                        {  
                            SUBTRACTION(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("multiply")===0) 
                        {   
                            MULTIPLY(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("division")===0)  
                        {  
                            DIVISION(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("idivision")===0) 
                        {  
                            IDIVISION(param_altfel_bis,i);
                        }
                        if(ope.toLowerCase().indexOf("modulo")===0)   
                        {
                            MODULO(param_altfel_bis,i);
                        }
                    }
                }
                if(i==linii.length) //DACA AM AJUNS LA SF FISIERULUI SI N AM DAT DE END
                    console.log("You have "+ parseInt(nr_if-nr_end) + " IF without END");
            }
        }
    return i;
    }
}
 
var linii = data.split("\n"); //SEPARA DATELE DIN FISIER PE LINII

for(let i=0; i<linii.length; i++)
{
    //console.log(linii[i]);
    if(linii[i].indexOf("&") === 0) //DACA AM COMENTARIU PE O LINIE
    {
        continue; //TREC MAI DEPARTE (LA LINIA URMATOARE) FARA SA FAC NIMIC
    }

    if(linii[i].indexOf(":")>0) //DACA AM UN STATEMENT
    {
        var l = linii[i].split(":"); //SEPARA CUVINTELE DE PE LINII DUPA :
        var op = l[0].trim(l[0]); //STOCHEAZA IN OP OPERATIA CURENTA
        l[1] = l[1].trim(l[1]);
        var param = l[1].split(/\s+/); //SEPARA LINIA (DEJA SEPARATA DUPA :) DUPA SPATIU

        //INIT
        if(op.toLowerCase().indexOf("init") === 0)
        {
            INIT(param,i);
        }

        //SET-COLOR
        if(op.toLowerCase().indexOf("set_color")===0)
        {
            SET_COLOR(param,i);
        }

        //LOCATION
        if(op.toLowerCase().indexOf("location") === 0)
        {
            LOCATION(param,i);
        }

        //DRAW_LINE
        if(op.toLowerCase().indexOf("draw_line") === 0)
        {
            DRAW_LINE(param,i);
        }

        //DRAW_CIRCLE
        if(op.toLowerCase().indexOf("draw_circle") === 0)
        {
            DRAW_CIRCLE(param,i);
        }

        //DRAW_ELLIPSE
        if(op.toLowerCase().indexOf("draw_ellipse") === 0)
        { 
            DRAW_ELLIPSE(param,i);
        }

        //DRAW-RECTANGLE
        if(op.toLowerCase().indexOf("draw_rectangle") === 0)
        { 
            DRAW_RECTANGLE(param,i);
        }

        //ADDITION
        if(op.toLowerCase().indexOf("addition") === 0)
        {
            ADDITION(param,i);
        }

        //SUBTRACTION
        if(op.toLowerCase().indexOf("subtraction") === 0)
        {
            SUBTRACTION(param,i);
        }

        //MULTIPLY
        if(op.toLowerCase().indexOf("multiply") === 0)
        {
            MULTIPLY(param,i);
        }

        //DIVISION
        if(op.toLowerCase().indexOf("division") === 0)
        {
            DIVISION(param,i);
        }

        //IDIVISION
        if(op.toLowerCase().indexOf("idivision") === 0)
        {
            IDIVISION(param,i);
        }

        //MODULO
        if(op.toLowerCase().indexOf("modulo") === 0)
        {
            MODULO(param,i);
        }

        //IF
        if(op.toLowerCase().indexOf("if") === 0)
        {
            i=IF(param,i);
        }

        //FOR LOOP
        if(op.toLowerCase().indexOf("for") === 0)
        {
            if(param.length!=1) //DACA NU AM FIX UN PARAM
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: FOR_LOOP needs 1 parameters, you wrote " + param.length);
                var verif = 1; //CHIAR SI CU MAI MULTI PARAM SE EXECUTA FOR-UL DE (primul param) ORI
            }
            if(param.length > 0 ) //DACA AM CEL PUTIN UN PARAM
            {
                if(isNaN(param[0])&&param[0].indexOf("$")!==0) //DACA PRIMUL PARAM NU E NICI VAR NICI NR
                {
                    console.log("LINE " + parseInt(i+1) + " HAS ERROR: FOR_LOOP parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
                }

                if(param[0].indexOf("$")===0) //PRIMUL PARAM E VAR
                {
                    var ok = 0;
                    for(let k=0;k<variabile.length; k++)
                    {
                        if(variabile[k].name == param[0].substring(1))
                        {
                            ok = 1;
                            param[0]=variabile[k].value;
                            break;
                        }
                    }
                    if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
                    {
                        console.log("LINE " + parseInt(i+1) + " HAS ERROR: FOR_LOOP parameter " + 1 + " needs to be a number or a variable, you wrote " + param[0]);
                    }
                }

                var cop = i; //RETINEM INTR-O COPIE LINIA DE UNDE INCEPEM SA TOT REPETAM INTRUCTIUNILE
                var de_cate_ori = param[0]; 

                for(let k=0; k<de_cate_ori; k++)
                {
                    var nr_for = 1; 
                    var nr_repeat = 0;
                    var repeat_not_ok = 0;
                    i=cop;
                    while(nr_for!=nr_repeat && i<linii.length)
                    {
                        i++;
                        if(i<linii.length && (linii[i].toLowerCase().indexOf('for_loop')>=0 || linii[i].toLowerCase().indexOf('while')>=0)) 
                            nr_for++;
                        if(i<linii.length && linii[i].toLowerCase().indexOf('repeat')>=0) 
                        {
                            nr_repeat++;
                            var l = linii[i].split(":"); //SEPARA CUVINTELE DE PE LINII DUPA :
                            if(l.length>1)
                            {
                                repeat_not_ok = 1;
                                var unde = i;
                            }
                        }
                        if(i<linii.length && linii[i].indexOf(":")>0) //DACA AM UN STATEMENT
                        {
                            var l = linii[i].split(":"); //SEPARA CUVINTELE DE PE LINII DUPA :
                            var op = l[0].trim(l[0]); //STOCHEAZA IN OP OPERATIA CURENTA
                            l[1] = l[1].trim(l[1]);
                            var param = l[1].split(/\s+/); //SEPARA LINIA (DEJA SEPARATA DUPA :) DUPA SPATIU

                            if(op.toLowerCase().indexOf("init")===0)
                            {
                                INIT(param,i);
                            }
                            if(op.toLowerCase().indexOf("set_color")===0)
                            {
                                SET_COLOR(param,i);
                            }
                            if(op.toLowerCase().indexOf("location")===0)
                            {
                                LOCATION(param,i);
                            }
                            if(op.toLowerCase().indexOf("draw_line")===0) 
                            {   
                                DRAW_LINE(param,i);
                            }
                            if(op.toLowerCase().indexOf("draw_circle")===0) 
                            {
                                DRAW_CIRCLE(param,i);
                            }
                            if(op.toLowerCase().indexOf("draw_ellipse")===0)  
                            { 
                                DRAW_ELLIPSE(param,i);
                            }
                            if(op.toLowerCase().indexOf("draw_rectangle")===0)    
                            {
                                DRAW_RECTANGLE(param,i);
                            }
                            if(op.toLowerCase().indexOf("addition")===0)  
                            {  
                                ADDITION(param,i);
                            }
                            if(op.toLowerCase().indexOf("subtraction")===0)  
                            {  
                                SUBTRACTION(param,i);
                            }
                            if(op.toLowerCase().indexOf("multiply")===0) 
                            {   
                                MULTIPLY(param,i);
                            }
                            if(op.toLowerCase().indexOf("division")===0)  
                            {  
                                DIVISION(param,i);
                            }
                            if(op.toLowerCase().indexOf("idivision")===0) 
                            {  
                                IDIVISION(param,i);
                            }
                            if(op.toLowerCase().indexOf("modulo")===0)   
                            {
                                MODULO(param,i);
                            }
                            if(op.toLowerCase().indexOf("if")===0)   
                            {
                                i=IF(param,i);
                            }
                        }
                    }
                    if(i==linii.length)
                    {
                        console.log("You have "+ parseInt(nr_for-nr_repeat) + " FOR_LOOP without REPEAT");
                        k = de_cate_ori;
                        i = unde-1;
                    }
                    if(repeat_not_ok == 1)
                    {
                        console.log("You have "+ 1 + " FOR_LOOP without REPEAT");
                        break;
                    }
                    if(verif == 1)
                        console.log("LINE " + parseInt(i+1) + " HAS ERROR: REPEAT and no WHILE/FOR_LOOP");
                }
            }
        }

        //WHILE
        if(op.toLowerCase().indexOf("while") === 0)
        {
            var poz=-1, verif;
            if(param.length!=1)
            {
                console.log("LINE " + parseInt(i+1) + " HAS ERROR: WHILE needs 1 parameters, you wrote " + param.length);
                verif = 1;
            }
            if(param.length > 0)
            {
                if(param[0].indexOf("$")!==0) //DACA PARAM NU E VAR 
                {
                    verif = 1;
                    console.log("LINE " + parseInt(i+1) + " HAS ERROR: WHILE parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
                }
                if(param[0].indexOf("$")===0) //PARAM E VAR
                {
                    var ok = 0;
                    for(let k=0;k<variabile.length; k++)
                    {
                        if(variabile[k].name == param[0].substring(1))
                        {
                            ok = 1;
                            poz=k;
                            param[0]=variabile[k].value;
                            break;
                        }
                    }
                    if(ok === 0) //DACA NU SE GASESTE PRIN VARIABILELE DEJA DECLARATE
                    {
                        console.log("LINE " + parseInt(i+1) + " HAS ERROR: WHILE parameter " + 1 + " needs to be a variable, you wrote " + param[0]);
                    }
                }

                var cop=i;
                while((poz>=0 && variabile[poz].value>0)||(verif==1 && poz==-1))
                {
                    var nr_for=1;
                    var nr_repeat = 0;
                    i=cop;
                    while(nr_for!=nr_repeat && i<linii.length)
                    {
                        i++;
                        if(i<linii.length && (linii[i].toLowerCase().indexOf('for_loop')>=0 || linii[i].toLowerCase().indexOf('while')>=0)) 
                            nr_for++;
                        if(i<linii.length && linii[i].toLowerCase().indexOf('repeat')>=0) 
                        {
                            var l = linii[i].split(":"); //SEPARA CUVINTELE DE PE LINII DUPA :
                            if(l.length==1)
                            {
                                nr_repeat++;
                            }
                            else var unde = i;
                        }

                        if(i<linii.length && linii[i].indexOf(":")>0) //DACA AM UN STATEMENT
                        {
                            var l = linii[i].split(":"); //SEPARA CUVINTELE DE PE LINII DUPA :
                            var op = l[0].trim(l[0]); //STOCHEAZA IN OP OPERATIA CURENTA
                            l[1] = l[1].trim(l[1]);
                            var param_altfel = l[1].split(/\s+/); //SEPARA LINIA (DEJA SEPARATA DUPA :) DUPA SPATIU

                            if(op.toLowerCase().indexOf("init")===0)
                            {
                                INIT(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("set_color")===0)
                            {
                                SET_COLOR(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("location")===0)
                            {
                                LOCATION(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("draw_line")===0) 
                            {   
                                DRAW_LINE(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("draw_circle")===0) 
                            {
                                DRAW_CIRCLE(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("draw_ellipse")===0)  
                            { 
                                DRAW_ELLIPSE(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("draw_rectangle")===0)    
                            {
                                DRAW_RECTANGLE(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("addition")===0)  
                            {  
                                ADDITION(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("subtraction")===0)  
                            {  
                                SUBTRACTION(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("multiply")===0) 
                            {   
                                MULTIPLY(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("division")===0)  
                            {  
                                DIVISION(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("idivision")===0) 
                            {  
                                IDIVISION(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("modulo")===0)   
                            {
                                MODULO(param_altfel,i);
                            }
                            if(op.toLowerCase().indexOf("if")===0)   
                            {
                                i = IF(param_altfel,i);
                            }
                        }
                    }
                    if(i==linii.length)
                    {
                        console.log("You have "+ parseInt(nr_for-nr_repeat) + " WHILE without REPEAT");
                        i = unde-1;
                        break;
                    }
                    if(verif == 1)
                    {
                        console.log("LINE " + parseInt(i+1) + " HAS ERROR: REPEAT and no WHILE/FOR_LOOP");
                        verif = 0;
                        break;
                    }
                }
            }
        }

        //REPEAT
        if(op.toLowerCase().indexOf("repeat") === 0)
        {
            if(param.length>0)
                console.log("LINE "+ parseInt(i+1)+ " HAS ERROR: REPEAT needs 0 parameters, you wrote " +param.length);
        }
    }
}

de_afisat +=  "\n" + "</svg>";

try {
    fs.writeFileSync(fisierout, de_afisat, 'utf8'); //SCRIEREA IN CANVAS.SVG
} catch(err) {
    console.error(err);
}