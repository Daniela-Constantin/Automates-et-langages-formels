"use strict";

var fs = require ('fs');

var fisierint = process.argv[2];
var fisierout = process.argv[3];

var parser = require ('./grammar.js').parser;

try {
    var data = fs.readFileSync(fisierint).toString(); //CITIREA DIN SCRIPT.ALF
} catch(err) {
   console.error(err);
}

try
{
	var info = parser.parse(data);
}
catch (e)
{
    console.log (e);
}

{
	try {
    fs.writeFileSync(fisierout, JSON.stringify (info, null, 4), 'utf8'); //SCRIEREA IN SCRIPT.ALF.JSON
	} catch(err) {
			console.error(err);
	}
}

/*

for_loop: FOR IDENTIFIER FROM value TO value RUN NEWLINE expressions END {
						$$ = {
							id: 'for',
							variable: $2,
							from: $4,
							to: $6,
							statements: $9,
							line: yylineno + 1
						};
					}
					| FOR IDENTIFIER FROM value TO function_call RUN NEWLINE expressions END {
						$$ = {
							id: 'for',
							variable: $2,
							from: $4,
							to: $6,
							statements: $9,
							line: yylineno + 1
						};
					}
					| FOR IDENTIFIER IN expr RUN NEWLINE expressions END {
						$$ = {
							id: 'for',
							variable: $2,
							exp: $4,
							statements: $7,
							line: yylineno + 1
						};
					};

loop_when: LOOP NEWLINE expressions WHEN expr {
							$$ = {
								id: 'loop_when',
								exp: $5,
								statements: $3,
								line: yylineno + 1
							};
						};

loop_run: LOOP expr RUN NEWLINE expressions END {
						$$ = {
							id: 'loop_run',
							exp: $2,
							statements: $5,
							line: yylineno + 1
						};
					};

function: FN IDENTIFIER ':' type '=>' expressions {
                        addFunct($2, null);
						$$ = {
							id: 'fn',
							title: $2,
							parameters: [],
							return_type: $4,
							statements: $6,
							line: yylineno + 1
						};
					}
					| FN IDENTIFIER ':' type LP parameters RP '=>' expressions {
						addFunct($2, $6);
                        $$ = {
							id: 'fn',
							title: $2,
							parameters: $6,
							return_type: $4,
							statements: $9,
							line: yylineno + 1
						};
                        deleteParameters();
					}
					| FN IDENTIFIER ':' type NEWLINE BEGIN NEWLINE expressions END {
						$$ = {
							id: 'fn',
							title: $2,
							parameters: [],
							return_type: $4,
							statements: $8,
							line: yylineno + 1
						};
					}
					| FN IDENTIFIER ':' type LP parameters RP NEWLINE BEGIN NEWLINE expressions END {
						addFunct($2, $6);
                        $$ = {
							id: 'fn',
							title: $2,
							parameters: $6,
							return_type: $4,
							statements: $11,
							line: yylineno + 1
						};
                        deleteParameters();
					};

function_call: IDENTIFIER LP parameters_call RP {
								$$ = {
									id: 'function_call',
									function: $1,
									parameters: $3,
									line: yylineno + 1
								};
							}
							| IDENTIFIER LP RP {
								$$ = {
									id: 'function_call',
									function: $1,
									parameters: [],
									line: yylineno + 1
								};
							};

parameters_call: parameters_call ',' IDENTIFIER ':' expr {
									$1[$3] = $5;
								}
								| parameters_call ',' IDENTIFIER ':' IDENTIFIER LP IDENTIFIER ':' expr RP {
									$$ = {
										id: 'function_call',
										function: $3,
										parameters: $1,
										line: yylineno + 1
									};
									$1[$7] = $9;
								}
								| IDENTIFIER ':' expr { 
									$$ = {};
									$$[$1] = $3;
								}; 

if: IF expr THEN NEWLINE expressions END {
			$$ = {
				id: 'if',
				exp: $2,
				then: $5,
				line: yylineno + 1
			};
		}
		| IF expr THEN NEWLINE expressions ELSE NEWLINE expressions END {
			$$ = {
				id: 'if',
				exp: $2,
				then: $5,
				else: $8,
				line: yylineno + 1
			};
		} 
		| IF function_call THEN NEWLINE expressions END {
				$$ = {
				id: 'if',
				exp: $2,
				then: $5,
				line: yylineno + 1
			};
		}
		| IF function_call THEN NEWLINE expressions ELSE NEWLINE expressions END {
			$$ = {
				id: 'if',
				exp: $2,
				then: $5,
				else: $8,
				line: yylineno + 1
			};
		} ;

struct: STRUCT IDENTIFIER NEWLINE properties END {
					$$ = {
						id: 'struct',
						title: $2,
						properties: $4
					};
				}
				| STRUCT IDENTIFIER NEWLINE END {
					$$ = {
						id: 'struct',
						title: $2,
						properties: []
					};
				};

properties: PROPERTY IDENTIFIER ':' type ';' NEWLINE {
							prop.push($1);
							$$ = [];
							$$.push({
								type: $4,
								title: $2,
								line: yylineno 
							});
						}
						| PROPERTY IDENTIFIER ':' type '=' value ';' NEWLINE {
							prop.push($1);
							$$ = [];
							$$.push({
								type: $4,
								title: $2,
								value: $6,
								line: yylineno 
							});
						}
						| properties PROPERTY IDENTIFIER ':' type ';' NEWLINE {
							prop.push($3);
							$1.push({
								type: $5,
								title: $3,
								line: yylineno 
							});
							$$ = $1;
						}
						| properties PROPERTY IDENTIFIER ':' type '=' value ';' NEWLINE {
							prop.push($3);
							$1.push({
								type: $5,
								title: $3,
								value: $7, 
								line: yylineno 
							});
							$$ = $1;
						};

access_prop: IDENTIFIER '.' IDENTIFIER '=' value {
							$$ = {
								id: 'set',
								to: {
									id: 'property',
									object: {
										id: 'identifier',
										title: $1,
										line: yylineno + 1
									},
									title: $3,
									line: yylineno + 1
								},
								from: $5,
								line: yylineno + 1
							};
						};

list: IDENTIFIER ':' type '[' INTEGER TO INTEGER ']' {
				$$ = {
					id: 'array',
					title: $1,
					element_type: $3,
					from: $5,
					to: $7,
					line: yylineno + 1
				};
			}
			| IDENTIFIER ':' IDENTIFIER '[' INTEGER TO INTEGER ']' {
				$$ = {
					id: 'array',
					title: $1,
					element_type: $3,
					from: $5,
					to: $7,
					line: yylineno + 1
				};
			};

access_array: IDENTIFIER '[' value ']' '=' value {
								$$ = {
									id: 'set',
									to: {
										id: 'element_of_array',
										array: $1,
										index: $3,
										line: yylineno + 1
									},
									from: $6,
									line: yylineno + 1
								};
							}
							| IDENTIFIER '[' IDENTIFIER '[' value ']' ']' '=' value {
								$$ = {
									id: 'set',
									to: {
										id: 'element_of_array',
										array: $1,
										index: {
											id: 'element_of_array',
											array: $3,
											index: $5,
											line: yylineno + 1
										},
										line: yylineno + 1
									},
									from: $9,
									line: yylineno + 1
								};
							}
							| IDENTIFIER '[' function_call ']' '=' value {
								$$ = {
									id: 'set',
									to: {
										id: 'element_of_array',
										array: $1,
										index: $3,
										line: yylineno + 1
									},
									from: $6,
									line: yylineno + 1
								};
							}
							| IDENTIFIER '[' IDENTIFIER '.' IDENTIFIER ']' '=' value {
								$$ = {
									id: 'set',
									to: {
										id: 'element_of_array',
										array: $1,
										index: {
											id: 'property',
											object : {
												id: 'identifier',
												title: $3,
												line: yylineno + 1
											},
											title: $5,
											line: yylineno + 1
										},
										line: yylineno + 1
									},
									from: $8,
									line: yylineno + 1
								};
							}
							| IDENTIFIER '[' value ']' '.' IDENTIFIER '=' value {
								$$ = {
									id: 'set',
									to: {
										id: 'property',
										object: {
											id: 'element_of_array',
											array: $1,
											index: $3,
											line: yylineno + 1
										},
										title: $6,
										line: yylineno + 1
									},
									from: $8,
									line: yylineno + 1
								};
							};

*/