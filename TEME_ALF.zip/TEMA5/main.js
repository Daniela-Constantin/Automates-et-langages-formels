"use strict";

var fs = require ('fs');

//CITIREA DIN FISIERUL TRANSMIS CA PARAMETRU CARE CONTINE AST-UL

var data = fs.readFileSync(process.argv[2], 'UTF-8');

var vector_variabile = [];
var webass = '';
var importuri = '';
var functii = '';
var modul = '';
var nr = 0;
var ok_char = 0;
var iteratie_for = -1;

function f_def(node)
{
    for(var elemIndex in node.elements)
    {
        functii += "(local $" + node.elements[elemIndex].title;
        if(node.elements[elemIndex].type === 'integer')
        {
            functii += " i32) \n";
        }
    }
}

function f_exp(node)
{
    if(node.left.id === 'exp')
    {
        f_exp(node.left);
    }
    if(node.left.id === 'identifier')
    {
        functii += "get_local $" + node.left.title + "\n";
    }
    if(node.left.id === 'function_call')
    {
        f_funcall(node.left);
    }
    if(node.left.id === 'value')
    {
        if(node.left.type === 'character')
        {
            functii += "i32.const " + node.left.value.charCodeAt(0) + "\n";
        }
    }
    
    if(node.right.id === 'exp')
    {
        f_exp(node.right);
    }
    if(node.right.id === 'identifier')
    {
        functii += "get_local $" + node.right.title + "\n";
    }
    if(node.right.id === 'function_call')
    {
        f_funcall(node.right);
    }
    if(node.right.id === 'value')
    {
        if(node.right.type === 'integer')
        {
            functii += "i32.const " + node.right.value + "\n";
        }
    }

    if(node.left.type === 'real' && node.right.type === 'integer')
    {
        functii += "f32.convert_s/i32 \n";
    }

    if(node.type === 'integer')
    {
        functii += "i32.";
    }
    if(node.type === 'real')
    {
        functii += "f32.";
    }
    if(node.type === 'logic')
    {
        functii += "i32.";
    }

    if(node.op === '+')
    {
        functii += "add \n";
    }
    if(node.op === '*')
    {
        functii += "mul \n";
    }
    if(node.op === '-')
    {
        functii += "sub \n";
    }
    if(node.op === '==')
    {
        functii += "eq \n";
    }
    if(node.op === 'or')
    {
        functii += "or \n";
    }
    if(node.op === '>')
    {
        functii += "gt_s \n";
    }
    if(node.op === '/')
    {
        functii += "div_s \n";
    }
    if(node.op === 'mod')
    {
        functii += "rem_s \n";
    }
    if(node.op === '>=')
    {
        functii += "ge_s \n";
    }

    if(node.left != undefined && node.left.type === 'character' && node.right.type === 'integer')
    {
        ok_char++;
        //functii += "i32.const 0x000000ff \n" + "i32.and \n";
    }
}

function f_set(node)
{
    if(node.from.id === 'exp')
    {
        f_exp(node.from);
    }
    if(node.from.id === 'identifier')
    {
        f_ident(node.from);
    }
    if(node.from.id === 'value')
    {
        if(node.from.type === 'integer')
        {
            functii += "i32.const " + node.from.value + "\n";
        }
    }

    if(node.to.type === 'integer' && node.from.type === 'real')
    {
        functii += "i32.trunc_s/f32 \n";
    }

    functii += "set_local $" + node.to.title + "\n";
}

function f_ident(node)
{
    functii += "get_local $" + node.title + "\n";
}

function f_funcall(node)
{
    for(var paramIndex in node.parameters)
    {
        if(node.parameters[paramIndex].id === 'identifier')
        {
            f_ident(node.parameters[paramIndex]);
        }
        if(node.parameters[paramIndex].id === 'value')
        {
            if(node.parameters[paramIndex].type === 'character')
            {
                functii += "i32.const " + node.parameters[paramIndex].value.charCodeAt(0) + "\n";
            }
        }
        if(node.parameters[paramIndex].id === 'exp')
        {
            f_exp(node.parameters[paramIndex]);
        }
    }
    if(node.function === 'writechar')
    {
        if(ok_char != 0)
        {
            functii += "i32.const 0x000000ff \n" + "i32.and \n";
            ok_char = 0;
        }
    }
    functii += "call $" + node.function + "\n";
}

function f_if(node)
{
    if(node.exp.id === 'exp')
    {
        f_exp(node.exp);
    }
    functii += "if \n";
    if(node.then[0].id === 'set')
    {
        f_set(node.then[0]);
    }
    if(node.then[0].id === 'function_call')
    {
        f_funcall(node.then[0]);
    }
    if(node.then[1] != undefined && node.then[1].id === 'set')
    {
        f_set(node.then[1]);
    }
    if(node.then[2] != undefined && node.then[2].id === 'if')
    {
        f_if(node.then[2]);
    }
    if(node.else != undefined)
    {
        functii += "else \n";
    }
    if(node.else != undefined && node.else[0].id === 'set')
    {
        f_set(node.else[0]);
    }
    if(node.else != undefined && node.else[0].id === 'function_call')
    {
        f_funcall(node.else[0]);
    }
    functii += "end \n";
}

var ast_parsat = JSON.parse(data);

var symbol = ast_parsat.symbol;
var ast = ast_parsat.ast;

var ok = 0;

//for(var k=0; k<symbol.length; k++)
//{
    var keys = Object.keys(symbol[0].variables);
    if(keys.length>0)
    {
        var obj = {};
        var cant = 0;
        for( var i of keys)
        {
            obj[i] = cant;
            cant += 4;
        }
        vector_variabile.push(obj);
        ok = 1;
    }
//}

if(ok === 0)
{
    vector_variabile.push({});
}

function writeSemantic(node)
{
    if(node.id === 'module')
    {
        modul = "(module" + "\n";
        webass+="(memory 1)\n(func $start\n";
        for(var statementIndex in node.statements)
        {
            writeSemantic(node.statements[statementIndex]);
        }
        webass+="return\n)\n(start $start)\n)"
    }
    else
    if(node.id === 'def')
    {

    }
    else 
    if(node.id === 'set')
    {
        writeSemantic(node.to);
        writeSemantic(node.from);
        if(node.from.id === 'identifier' && node.from.type === 'integer')
        {
            webass += "i32.load \n";
        }
        if(node.to.type !== node.from.type)
        {
            if(node.to.type === 'real')
            {
                webass += 'f32.convert_s/';
                if(node.from.type === 'integer')
                {
                    webass += "i32 \n";
                }
                webass += "f32.store \n";
            }
            if(node.to.type === 'integer')
            {
                webass += 'i32.convert_s/';
                if(node.from.type === 'real')
                {
                    webass += "f32 \n";
                }
                webass += "i32.store \n";
            }
            if(node.to.type === 'character')
            {
                webass += "i32.store \n";
            }
        }
        else
        {
            if(node.from.type === 'integer')
            {
                webass += "i32.store \n";
            }
            if(node.from.type === 'logic')
            {
                if(vector_variabile[0][node.from.title] != undefined)
                {
                    webass += "i32.load \n";
                }
                webass += "i32.store \n";
            }
            if(node.from.type === 'real')
            {
                webass += "f32.store \n";
            }
            if(node.from.type === 'character')
            {
                webass += "i32.store \n";
            }
        }
    }
    else
    if(node.id === 'exp')
    {
        if(node.left !== undefined)
        {
            writeSemantic(node.left);
            if(node.left.type === 'integer')
            {
                if(node.right.type === 'real')
                {
                    webass += 'f32.convert_s/';
                    webass += "i32 \n";
                }
            }
            if(node.left. id === 'identifier' && node.left.type === 'integer')
            {
                webass += "i32.load \n";
            }
            if(node.left.type === 'character')
            {
                webass += "i32.load \n";
            }
        }

        if(node.right !== undefined)
        {
            writeSemantic(node.right); 
            if(node.left.type === 'real')
            {
                webass += 'f32.convert_s/';
                if(node.right.type === 'integer' || node.right.type === 'character')
                {
                    webass += "i32 \n";
                }
            }
            if(node.right. id === 'identifier' && node.right.type === 'integer')
            {
                webass += "i32.load \n";
            }
        }

        if(node.op === 'not')
        {
            writeSemantic(node.value);
            webass += "i32.load \n";
            webass += "i32.const 0 \n";
            webass += "i32.eq \n";
        }

        if(node.op === '+')
        {
            if(node.left.type === 'real' || node.right.type === 'real')
            {
                webass += "f32.add \n";
            }
            else
            {
                webass += "i32.add \n";
            }
        }
        if(node.op === '*')
        {
            webass += "i32.mul \n";
        }
        if(node.op === "/")
        {
            webass += "i32.div_s \n";
        }
        if(node.op === ">")
        {
            webass += "i32.gt_s \n";
        }
        if(node.op === "<")
        {
            webass += "i32.lt_s \n";
        }
        if(node.op === "!=")
        {
            webass += "i32.ne \n";
        }
        if(node.op === "xor")
        {
            webass += "i32.xor \n";
        }
        if(node.op === "and")
        {
            webass += "i32.and \n";
        }
        if(node.op === "==")
        {
            webass += "i32.eq \n";
        }
        if(node.op === "mod")
        {
            webass += "i32.rem_s \n";
        }
        if(node.op === "!=" && node.right.value === 0)
        {
            webass += "i32.eqz \n";
        }
        if(node.op === '>=')
        {
            webass += "i32.ge_s \n";
        }

        if(node.left != undefined && node.left.type === 'character' && node.right.type === 'integer')
        {
            webass += "i32.const 0x000000ff \n" + "i32.and \n";
        }
    }
    else
    if(node.id === 'value')
    {
        if(node.type === 'integer')
        {
            webass += "i32.const " + node.value + "\n";
        }
        if(node.type === 'real')
        {
            webass += "f32.const " + node.value + "\n";
        }
        if(node.type === 'logic')
        {
            if(node.value === false)
            {
                webass += "i32.const " + 0 + "\n";
            }
            if(node.value === true)
            {
                webass += "i32.const " + 1 + "\n";
            }
        }
        if(node.type === 'character')
        {
            var c = node.value;
            webass += "i32.const " + c.charCodeAt(0) + "\n";
        }
    }
    else
    if(node.id === 'identifier')
    {
        var t = node.title;
        if(node.type === 'integer')
        {
            webass += "i32.const " + vector_variabile[0][t] + "\n";
        }
        if(node.type === 'real')
        {
            webass += "i32.const " + vector_variabile[0][t] + "\n";
        }
        if(node.type === 'logic')
        {
            webass += "i32.const " + vector_variabile[0][t] + "\n";
        }
        if(node.type === 'character')
        {
            webass += "i32.const " + vector_variabile[0][t] + "\n";
        }
    }
    else
    if(node.id === 'fn')
    {
        if(node.title === 'writeint')
        {
            importuri += '(import "io" "writeint" (func $writeint (param $int i32))) \n';
            for(var statsIndex in node.statements)
            {
                writeSemantic(node.statements[statsIndex]);
            }
        }
        if(node.title === 'writefloat')
        {
            importuri += '(import "io" "writefloat" (func $writefloat (param $float f32))) \n';
            for(var statsIndex in node.statements)
            {
                writeSemantic(node.statements[statsIndex]);
            }
        }
        if(node.title === 'readint')
        {
            importuri += '(import "io" "readint" (func $readint (result i32))) \n';
            for(var statsIndex in node.statements)
            {
                writeSemantic(node.statements[statsIndex]);
            }
        }
        if(node.title === 'readfloat')
        {
            importuri += '(import "io" "readfloat" (func $readfloat (result f32))) \n';
            for(var statsIndex in node.statements)
            {
                writeSemantic(node.statements[statsIndex]);
            }
        }
        if(node.title === 'writechar')
        {
            importuri += '(import "io" "writechar" (func $writechar (param $char i32))) \n';
            for(var statsIndex in node.statements)
            {
                writeSemantic(node.statements[statsIndex]);
            }
        }
        if(node.title === 'sum' || node.title === 'floatwrite' || node.title === 'fibonacci' || node.title === 'base16')
        {
            var nr_return = 0;
            if(node.title === 'sum')
            {
                functii += "(func $sum \n";
            }
            if(node.title === 'floatwrite')
            {
                functii += "(func $floatwrite \n";
            }
            if(node.title === 'fibonacci')
            {
                functii += "(func $fibonacci \n";
            }
            if(node.title === 'base16')
            {
                functii += "(func $base16 \n";
            }
            for(var paramIndex in node.parameters)
            {
                functii += "(param $" + node.parameters[paramIndex].name;
                if(node.parameters[paramIndex].type === 'integer')
                {
                    functii += " i32) \n";
                } 
                if(node.parameters[paramIndex].type === 'real')
                {
                    functii += " f32) \n";
                } 
            }
            if(node.return_type === 'integer')
            {
                functii += "(result i32) \n";
            }
            for(var statsIndex in node.statements)
            {
                var n = node.statements[statsIndex];
                if(n.id === 'return')
                {
                    if(n.value.id === 'exp')
                    {
                        f_exp(n.value);
                    }
                    if(n.value.id === 'identifier')
                    {
                        f_ident(n.value);
                    }
                    nr_return++;
                    functii += "return \n";
                    functii += ") \n";
                }
                if(n.id === 'def')
                {
                    f_def(n);  
                }
                if(n.id === 'set')
                {
                    f_set(n);
                }
                if(n.id === 'function_call')
                {
                    f_funcall(n);
                }
                if(n.id === 'if')
                {
                    f_if(n);
                }
            }
            if(nr_return == 0)
            {
                functii += ") \n";
            }
        }
    }
    else
    if(node.id === 'return')
    {
        
    }
    else
    if(node.id === 'function_call')
    {
        for(var paramIndex in node.parameters)
        {
            writeSemantic(node.parameters[paramIndex]);
            if(node.function === 'writeint')
            {
                if(vector_variabile[0][node.parameters[paramIndex].title] !== undefined)
                {
                    if(node.parameters[paramIndex].type === 'real')
                    {
                        webass += "f32.load \n";
                    }
                    if(node.parameters[paramIndex].type === 'integer')
                    {
                        webass += "i32.load \n";
                    }
                }   
                if(node.parameters[paramIndex].type === 'real')
                {
                    webass += "i32.trunc_s/f32 \n";
                }   
            }
            if(node.function === 'writefloat')
            {
                if(node.parameters[paramIndex].type === 'real')
                {
                    webass += "f32.load \n";
                }
            }
            if(node.function === 'writechar')
            {
                if(node.parameters[paramIndex].type === 'character')
                {
                    webass += "i32.load \n";
                }
            }
            if(node.function === 'floatwrite')
            {
                webass += "f32.load \n";
            }
            if(node.function === 'fibonacci')
            {
                webass += "i32.load \n";
            }
            if(node.function === 'base16')
            {
                webass += "i32.load \n";
            }
        }
        webass += "call $" +  node.function + "\n";
        nr += 4;
    }
    else
    if(node.id === 'if')
    {
        writeSemantic(node.exp);
        webass += "if \n";
        writeSemantic(node.then[0]);
        if(node.else != undefined)
        {
            webass += "else \n";
            writeSemantic(node.else[0]);
        }
        webass += "end \n";
    }
    else
    if(node.id === 'loop_run')
    {
        webass += "block $while_0_end \n";
        webass += "loop $while_0_begin \n";
        writeSemantic(node.exp);
        if(node.exp.op === 'not')
        {
            webass += "i32.eqz \n";
        }
        webass += "br_if $while_0_end \n";
        for(var k = 0; k< node.statements.length; k++)
        {
            writeSemantic(node.statements[k]);
        }
        webass += "br $while_0_begin \n";
        webass += "end $while_0_begin \n";
        webass += "end $while_0_end \n";
    }
    else
    if(node.id === 'for')
    {
        iteratie_for++;
        //from
        if(vector_variabile[0][node.variable] != undefined)
        {
            webass += "i32.const " + vector_variabile[0][node.variable] + "\n";
        }
        writeSemantic(node.from);
        if(node.from.id === 'identifier')
        {
            webass += "i32.load \n";
        }
        webass += "i32.store \n";
        webass += "block $for_" + iteratie_for +"_end \n";
        webass += "loop $for_" + iteratie_for + "_begin \n";

        //to
        if(vector_variabile[0][node.variable] != undefined)
        {
            webass += "i32.const " + vector_variabile[0][node.variable] + "\n";
        }
        webass += "i32.load \n";
        writeSemantic(node.to);
        if(node.to.id === 'identifier')
        {
            webass += "i32.load \n";
        }
        webass += "i32.gt_s \n";

        webass += "br_if $for_" + iteratie_for + "_end \n";
        for(var k = 0; k< node.statements.length; k++)
        {
            writeSemantic(node.statements[k]);
        }

        //iteratie
        if(vector_variabile[0][node.variable] != undefined)
        {
            webass += "i32.const " + vector_variabile[0][node.variable] + "\n";
            webass += "i32.const " + vector_variabile[0][node.variable] + "\n";
        }
        webass += "i32.load \n";
        webass += "i32.const 1 \n";
        webass += "i32.add \n";
        webass += "i32.store \n";

        webass += "br $for_" + iteratie_for + "_begin \n";
        webass += "end $for_" + iteratie_for + "_begin \n";
        webass += "end $for_" + iteratie_for + "_end \n";
    }
    else
    if(node.id === 'loop_when')
    {
        webass += "loop $repeat_0 \n";
        for(var k = 0; k< node.statements.length; k++)
        {
            writeSemantic(node.statements[k]);
        }
        writeSemantic(node.exp);
        webass += "br_if $repeat_0 \n";
        webass += "end $repeat_0 \n";
    }
}

writeSemantic(ast);
var final = modul + importuri + functii + webass;

//SCRIEREA IN FISIERUL TRANSMIS CA PARAMETRU A CODULUI IN WEB ASSEMBLY


try {
    fs.writeFileSync(process.argv[3], final, 'utf8'); 
} catch(err) {
    console.error(err);
}

//SCRIEREA IN FISERUL DE VARIABILE A VARIABILELOR ALOCATE

var output = process.argv[3] + ".variables.json";
try {
    fs.writeFileSync(output, JSON.stringify(vector_variabile, null, 4), 'utf8'); 
} catch(err) {
    console.error(err);
}