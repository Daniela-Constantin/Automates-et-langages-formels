Constantin Daniela 
1220F

o Citirea + scrierea in fisier

Am citit de la tastatura fisierul de input. Avand in vedere ca primim ca input un AST deja parsat,
iar functia mea principala (writeSemantic) cere ca parametru un obiect (node), a trebuit sa 
convertesc tipul variabilei care stocheaza datele de intrare cu ajutorul comanzii JSON.parse.
Pentru output am considerat urmatoarele 2 variante:
	- fie ni se da din command prompt fisierul in care se va face afisarea
	- fie il generez automat, avand grija sa-i dau acelasi nume ca fisierul de input

o "Pregatirea terenului" pentru output

In output se vrea afisarea unui obiect care contine tabela de simboluri, ast-ul dat ca input,
cu mici modificari si tabloul cu erori.

	- SYMBOL TABLE

	Eu am gandit symbol table-ul ca fiind un vector care reuneste mai multi vectori de obiecte.
	Fiecare element al tabelei de simboluri (variabile, functii, tipuri, parinte-daca e cazul-
	si tip) este deci un vector. Index-ul vectorului este echivalent cu "symbol" (nivelul la
	care sunt - de exemplu, in cazul unei functii, parametrii sai vor fi considerati de nivel
	1, deoarece nu sunt vizibili in afara functiei). Pe fiecare pozitie din acesti vectori am
	mai multe obiecte (daca definesc doua variabile in interiorul nodului "module", 
	vectorul de variabile va avea pe pozitia 0 doua obiecte, fiecare pentru cate o variabila
	adaugata). Pentru a adauga elemente in acesti vectori am creat functii cu nume sugestive
	(addVariable, addType etc.)

	- AST
	
	Ast-ul este in mare parte identic cu ce primesc ca input, doar ca se adauga una/doua 
	proprietati nodurilor, dupa caz, si anume "symbol" si "type". Pentru a realiza acest
	lucru am creat un obiect intitulat "astModificat" care contine initial id-ul primului
	nod (anume "module"), lista de statementuri, randul si nivelul/symbol. Pe langa adaugarea
	acestei proprietati din urma, diferanta la astModificat se afla si in vectorul de 
	statementuri. Am creat un vector "sts" => statements, in care adaug nodurile dupa ce le
	modific, acest lucru dealizandu-se recursiv. Am intampinat aici dificultatea de a avea 
	mai multe statementuri in ast-ul modificat decat in cel original, din cauza faptului ca
  	adaug toate nodurile (cu id-ul value sau identifier spre exemplu) in lista de statementuri
	din motive de modificare automata a ast-ului. Am reusit sa rezolv aceasta problema stergand 
	statementu-rile suplimentare, lasand in sts doar numarul de statementuri din ast-ul original.

	- ERROR_LIST

	Error_list este si el un vector in care adaug erori sub forma de obiecte cu tip, rand, elemente
	(care este la randul lui un obiect) si text. Pentru realizarea acestuia, pur si simplu
	am adaugat in vectorul "error_list" orice eroare pe care o intalneam in urma analizei
	nodurilor. Aici m-am folosit de toate "constructiile" din urma: lista de variabile, tipuri etc.
	precum si ast-ul modificat. 

In final, am adaugat in "obiectulMare" symbol_table-ul, ast-ul modificat si error_list. Pentru 
afisarea in maniera dorita, am converit acest obiect la un fisier jison cu ajutorul JSON.stringify.