"use strict";

var fs = require ('fs');

var ast = fs.readFileSync(process.argv[2], 'UTF-8');

var obiectulMare = {};

var symbol_table = [];

var v = [];
v[0] = {};

var p = [];
p[0] = {};

var f = [];
f[0] = {};

var t = [];
t[0] = {};
var prop = [];

var ty = [];
ty[0] = '';

var par = [];
var fct = [];
var rt = [];

var astModificat = {};
var sts = [];

var error_list = [];

var symb = 0;
var max = 0;

function addVariable (index, variable, type, line)
{
    v[index][variable] = {
        type: type,
        line: line 
    };
}

function addVariable_value (index, variable, type, value, line)
{
    if(v[index][variable] !== undefined)
    {
        error_list.push({
            type: 'VARIABLE_ALREADY_DEFINED',
            line: line,
            elements: {
                variable: variable
            },
            text: "variable " + variable + " is already defined"
        });
    }
    else
    {
        v[index][variable] = {
            type: type,
            value: value,
            line: line 
        };
    }
}

function addParameter (index, param, type, line)
{
    p[index][param] = {
        type: type,
        line: line 
    };
}

function addFunction (index, name, type, parameters, symbol, line)
{
    f[index][name] = {
        type: type,
        parameters: parameters, 
        symbol: symbol,
        line: line
    };
}

function addType (index, name, properties)
{
    var temp = [];
    var ok = 1;
    for(var k = 0; k<properties.length; k++)
    {
        if(k>0)
        {
            for(var q = 0; q<k; q++)
            {
                if(properties[q].title === properties[k].title)
                {
                    ok = 0;
                    error_list.push({
                        type: 'CLASS_PROPERTY_ALREADY_DEFINED',
                        line: properties[k].line,
                        elements: {
                            struct: name
                        },
                        text: "struct's " + name + " element title is already defined"
                    });
                }
            }
        }
        if(ok == 1)
        {
            if(properties[k].value !== undefined)
                {
                    properties[k].value.symbol = index;
        
                    temp.push({
                        type: properties[k].type,
                        title: properties[k].title,
                        line: properties[k].line,
                        value: properties[k].value
                    });
                }
               
                prop.push({
                    type: properties[k].type,
                    title: properties[k].title, 
                    line: properties[k].line
                });
        }
    }

    if(temp.length>0)
    {
        t[index][name] = {
            type: "struct",
            properties: temp
        }
    }
    else
    {
        t[index][name] = {
            type: "struct",
            properties: prop
        }
    }
}

function addType_array(index, name, line, elem_type, from, to)
{
    t[index][name] = {
        type: "array",
        line: line,
        element_type: elem_type,
        from: from,
        to: to
    }
}

function getType (element1, element2, op) {
	let a;
    let b;
    
    if(op == 'and' || op == '>' || op == '<' || op == '==' || op == 'xor' || op == 'or' || op == '!=')
    {
        return 'logic';
    }

    if(element1.id === 'value' || element1.id == 'identifier')
    {
        a = element1.type;
    }
    else
    if(element1.id === 'exp')
    {
        a = getType(element1.left, element1.right, element1.op);
    }

    if(element2.id === 'value' || element2.id == 'identifier')
    {
        b = element2.type;
    }
    else
    if(element2.id === 'exp')
    {
        b = getType(element2.left, element2.right, element2.op);
    }

	if (a === b) {
		return a;
	}

	if(a === 'real' || b === 'real') {
		return 'real';
    }

    if(a === 'string' || b === 'string')
    {
        return 'string';
    }

    if(a === '' || b === '')
    {
        return '';
    }

    if(a === 'logic' || b === 'logic')
    {
        return '';
    }

    if(a === 'integer' || b === 'integer')
    {
        return 'integer';
    }
    
    return "nu_stiu";
}

function writeSemantic(node)
{
    if(node.id === 'module')
    {
        ty[symb] = 'module';
        for(var statementIndex in node.statements)
        {
            writeSemantic(node.statements[statementIndex]);
        }

        for(var k=sts.length; k>node.statements.length; k--)
        {
            sts.pop();
        }

        astModificat.id = 'module';
        astModificat.statements = sts;
        astModificat.line = node.line;
        astModificat.symbol = symb;
    }
    else
    if(node.id === 'def')
    {
        sts.push(node);
        for(var elementsIndex in node.elements)
        {
            if(v[symb][node.elements[elementsIndex].title] !== undefined)
            {
                if(node.elements[elementsIndex].value !== undefined)
                {
                    node.elements[elementsIndex].value.symbol = symb;
                    error_list.push({
                        type: 'VARIABLE_ALREADY_DEFINED',
                        line: node.line,
                        elements: {
                            variable: node.elements[elementsIndex].title
                        },
                        text: "variable " + node.elements[elementsIndex].title + " is alredy defined"
                    });
                }
            }
            else
            {
                if(node.elements[elementsIndex].value === undefined)
                {
                    addVariable(symb,node.elements[elementsIndex].title, node.elements[elementsIndex].type, node.elements[elementsIndex].line);
                }
                else
                {
                    node.elements[elementsIndex].value.symbol = symb;
                    node.elements[elementsIndex].value.type = node.elements[elementsIndex].type;
                    if(node.elements[elementsIndex].value.id === 'exp')
                    {
                        writeSemantic(node.elements[elementsIndex].value.left);
                        writeSemantic(node.elements[elementsIndex].value.right);
                    }
                    addVariable_value(symb, node.elements[elementsIndex].title, node.elements[elementsIndex].type, node.elements[elementsIndex].value, node.elements[elementsIndex].line);
                }
            }  
        }  
        node.symbol = symb;
    }
    else 
    if(node.id === 'set')
    {
        node.symbol = symb;
        sts.push(node);
      
        writeSemantic(node.to);
        writeSemantic(node.from);

        if(node.to.type !== node.from.type)
        {
            error_list.push({
                type: 'TYPE_EXPRESSION',
                line: node.line,
                elements: {
                    op: '=',
                    to: node.to.type,
                    from: node.from.type
                },
                text: "Type expression error " + node.to.type + " is " + node.from.type
            });
        }
    }
    else
    if(node.id === 'exp')
    {
        sts.push(node);

        if(node.left !== undefined)
        {
            node.left.symbol = symb;
            writeSemantic(node.left);
        }
        if(node.right !== undefined)
        {
            node.right.symbol = symb;
            writeSemantic(node.right); 
        }

        node.symbol = symb;
        if(node.left !== undefined && node.right !== undefined)
        {
            node.type = getType(node.left, node.right, node.op);
        }
        else
        {
            if(node.value !== undefined)
            {
                writeSemantic(node.value);
                node.type = node.value.type;
            }
        }

        if(node.type === '' && ((node.left.id !== 'value' && v[symb][node.left.title] !== undefined) && (node.right.id !== 'value' && v[symb][node.right.title] === undefined )))
        {
            error_list.push({
                type: "TYPE_EXPRESSION",
                line: node.line,
                elements: {
                    left: node.left.type,
                    right: node.right.type,
                    op: node.op
                },
                text: "Type expression error " + node.left.type + " + " + node.right.type
            });
        }
    }
    else
    if(node.id === 'value')
    {
        node.symbol = symb;
    }
    else
    if(node.id === 'identifier')
    {
        node.symbol = symb;
        if(v[symb][node.title] !== undefined)
        {
            node.type = v[symb][node.title].type; 
        }
        else
        if(p[symb][node.title] !== undefined)
        {
            node.type = p[symb][node.title].type;
        }
        else
        {
            node.type = '';
            if(v[symb][node.title] === undefined)
            {
                error_list.push({
                    type: "UNDEFINED_VARIABLE",
                    line: node.line,
                    elements: {
                        variable: node.title
                    },
                    text: "undefined variable " + node.title
                });
            }
        }
    }
    else
    if(node.id === 'fn')
    {
        symb++;
        max++;

        v[symb] = {};
        p[symb] = {};
        f[symb] = {};
        t[symb] = {};
        ty[symb] = 'function';
        fct[symb] = node.title;
        rt[symb] = node.return_type;
        par[symb] = symb-1;

        addFunction(symb-1, node.title, node.return_type, node.parameters, symb, node.line);

        sts.push(node);
        for(var paramIndex in node.parameters)
        {
            addParameter(symb, node.parameters[paramIndex].name, node.parameters[paramIndex].type, node.parameters[paramIndex].line);
            node.parameters[paramIndex].symbol = symb;
        }

        for(var statsIndex in node.statements)
        {
            writeSemantic(node.statements[statsIndex]);
        }

        node.symbol = symb;
        symb--;
    }
    else
    if(node.id === 'return')
    {
        sts.push(node);

        node.symbol = symb;
        if(v[symb][node.value.title] !== undefined)
        {
            node.type = v[symb][node.value.title].type;
        }
        else
        {
            node.type = '';
        }

        if((symb > 0 && f[symb-1] === undefined) || (symb === 0 && f[symb].length === undefined))
        {
            error_list.push({
                type: "RETURN_OUTSIDE_FUNCTION",
                line: node.line,
                elements: {
                },
                text: "value is used out of function"
            });

            
            if(node.type !== node.value.type)
            {
                error_list.push({
                    type: "TYPE_EXPRESSION",
                    line: node.value.line,
                    elements: {
                        op: node.value.id,
                        required: node.type
                    },
                    text: "Type expression error " + node.value.id
                });
            }
        }

        writeSemantic(node.value);
    }
    else
    if(node.id === 'function_call')
    {
        node.symbol = symb;
        if(f[symb][node.function] !== undefined)
        {
            node.type = f[symb][node.function].type;
        }
        else
        {
            node.type = '';
            error_list.push({
                type: 'UNDEFINED_FUNCTION',
                line: node.line,
                elements: {
                    id: node.function
                },
                text: "Undefined function " + node.function
            });
        }
        for(var paramIndex in node.parameters)
        {
            node.parameters[paramIndex].symbol = symb;
        } 
        sts.push(node);
    }
    else
    if(node.id === 'struct')
    {
        if(t[symb][node.title] !== undefined)
        {
            error_list.push({
                type: "TYPE_ALREADY_DEFINED",
                elements: {
                    type: node.title
                },
                text: "type " + node.title + " is already defined"
            });
        }
        else
        {
            addType(symb, node.title, node.properties);
        }
        node.symbol = symb;
        sts.push(node);
    }
    else
    if(node.id === 'property')
    {
        node.symbol = symb;
        
        var ok = 0;
        for(var k=0; k<prop.length; k++)
        {
            if(prop[k].title == node.title)
            {
                node.type = prop[k].type;
                ok = 1;
            }    
        }
        if(ok == 0)
        {
            node.type = "";
        }

        writeSemantic(node.object);

        //if(t[symb][node.object.title] === undefined && t[symb][v[symb][node.object.title].type].type !== 'struct')
        if(t[symb][v[symb][node.object.title].type] !== undefined && t[symb][v[symb][node.object.title].type].type !== 'struct')
        {
            error_list.push({
                type: "NOT_STRUCT",
                line: node.object.line,
                elements: {
                    type: node.object.type
                },
                text: node.object.type + " is not a struct"
            });
        }
    }
    else
    if(node.id === 'array')
    {
        addType_array(symb, node.title, node.line, node.element_type, node.from, node.to);
        node.symbol = symb;

        if(node.from>node.to)
        {
            error_list.push({
                type: "ARRAY_INDEX_VALUE",
                line: node.line,
                elements: {
                    array: node.title,
                    low_index: node.from,
                    high_index: node.to
                },
                text: "Array index lower value (" + node.from + ") must be smaller than the upper value (" + node.to + ")"
            });
        }

        sts.push(node);
    }
    else
    if(node.id === 'element_of_array')
    {
        writeSemantic(node.index);
        //if(t[symb][node.array] === undefined && t[symb][v[symb][node.array].type].type !== 'array')
        if(t[symb][v[symb][node.array].type] !== undefined && t[symb][v[symb][node.array].type].type !== 'array')
        {
            error_list.push({
                type: "NOT_ARRAY",
                line: node.line,
                elements: {
                    type: node.array
                },
                text: node.array + " is not an array"
            });
        }
        node.symbol = symb;
        var temp = v[symb][node.array].type;
        if(t[symb][temp] !== undefined)
        {
            node.type = t[symb][temp].element_type;
        }
        else
        {
            node.type = '';
        }
        if(node.index.type === 'string' || node.index.type === '')
        {
            error_list.push({
                type: "ARRAY_INDEX_TYPE",
                line: node.line,
                elements: {
                    array: node.array,
                    index: node.index.type
                },
                text: "Array (" +  node.array + ") index must be integer or character"
            });
        }
    }
}

writeSemantic(JSON.parse(ast));

for(var k=0; k<max+1; k++)
{
    symbol_table.push({variables:v[k], functions:f[k], types:t[k], parent: par[k], type:ty[k], function: fct[k], return_type:rt[k]});
}

obiectulMare.symbol_table = symbol_table;
obiectulMare.ast = astModificat;
obiectulMare.error_list = error_list;

if(process.argv[3] !== undefined)
{
    try {
        fs.writeFileSync(process.argv[3], JSON.stringify(obiectulMare, null, 4), 'utf8'); 
     } catch(err) {
        console.error(err);
    }
}
else
{
    var nume_fis = process.argv[2];
    //console.log(nume_fis);
    var output = nume_fis.split(".")[0] + ".alf.json";
    //console.log(output);
    try {
        fs.writeFileSync(output, JSON.stringify(obiectulMare, null, 4), 'utf8'); 
     } catch(err) {
        console.error(err);
    }
}
