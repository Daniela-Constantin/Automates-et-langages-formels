"use strict";

var fs = require ('fs');

var fisierint = process.argv[2];
var fisierout = process.argv[3];

try {
    var data = fs.readFileSync(fisierint).toString(); //CITIREA DIN SCRIPT.ALF
} catch(err) {
   console.error(err);
}

var parser = require ('./grammar.js').parser;

try
{
	var info = parser.parse (data);
}
catch (e)
{
    console.log (e);
}

{
	try {
    fs.writeFileSync(fisierout, JSON.stringify (info, null, 4), 'utf8'); //SCRIEREA IN SCRIPT.ALF.JSON
	} catch(err) {
			console.error(err);
	}
}


// val string: \"[\\\r\n]*[^\"]*\"

/* 
						| PROPERTY IDENTIFIER ':' type ';' NEWLINE properties {
							$7.splice(0,0, {
								type: $4,
								title: $2,
								line: yylineno + 1});
							$$ = $7;
						} */