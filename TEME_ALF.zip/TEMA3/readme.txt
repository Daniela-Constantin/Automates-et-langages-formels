CONSTANTIN Daniela Alexandra 
1220F

1) START 
Avand in vedere faptul ca unele input-uri pot contine comenatarii pe prima linie am ales sa incep prin a verifica acest lucru. Fie am COMENTARIU, urmat (sau nu) de o
noua linie si mai apoi EXPRESII, fie se incepe direct cu EXPRESIILE

2) EXPRESSIONS
Din nou, in functie de existenta sau nu a separatorilor ';' si NEWLINE am adaugat toate variantele posibile 

3) STATEMENTS
Un statement, precum specificat si in cerinta, poate fi fie value, expr, attribution, deffinition etc.

4) VALUE 
De tip real, integer, string_value, logic (true sau false) sau IDENTIFIER

5) DEFINITION 
Definirea unei variabile arata in felul urmator: cuvantul 'def' + variables. Pe acestea din urma, le-am definit in aceeasi maniera ca pe expresii, in functie de modul in 
care se prezinta ( daca e vorba de una sau mai multe variabile, daca au numai tip, daca au numai valoare, daca au si tip si valoare etc.), avand grija la elementele de 
legatura ( ':' - inainte de tip , '=' - inainte de valoare , ',' - intre variabile etc.)

6) TYPE
Se refera la tipul variabilelor: int, float, logic, array sau structura.

7) ASSIGN 
Atribuirea unei variabile o valoare, in afara definirii. 

8) EXPR
Cazuri de expresii matematice/ operatii (adunare, scadere, etc.)

9) FOR_LOOP, LOOP_WHEN, LOOP_RUN, IF
Diferitele tipuri de loop-uri, ce contin in interior expresii si se termina cu END.

10) FUNCTION
Definirea de functii, care incep mereu cu FN si se incheie cu END (daca sunt mai complexe) sau doar indica ce returneaza (dupa indicatorul 
'=>' ; se intind pe un singur rand). Contin parametrii, intre paranteze, pentru a-mi permite tratarea tuturor cazurilor posibile.

11) PARAMETERS 
Pot exista mai multi parametrii, sau doar unul 

12) FUNCTION_CALL si PARAMETERS_CALL 
Se refera la apelarea unei functii, de aceea, au o structura diferita fata de FUNCTION si PARAMETERS

13) STRUCT, PROPERTIES si ACCESS_PROP
In STRUCT am tratat strict cazurile de definire ale unui struct, urmand ca in PROPERTIES sa ma ocup de diferitele campuri posibile, iar in ACCES_PROP sa initializez aceste proprietati.

14) LIST si ACESS_ARRAY
La fel ca la structuri, in LIST am definit vectorii, in toate modurile posibile, iar cu ACCESS_ARRAY le-am acordat valori. 


