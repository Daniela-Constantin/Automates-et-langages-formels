"use strict";
var cowsay = require("cowsay");

var operation = process.argv[2];
var vect = process.argv;
var operations = ["display" , "addition" , "subtraction" , "division" , "multiply" , "modulo" , "sqrt" , "absolute" , 
"power" , "sort" , "reverse" , "maximum" , "minimum" , "unique" , "cosinus" , "sinus", undefined];

if(!operations.includes(operation))
    console.log("ERROR: this command does not exist, use display to see available commands");
else
{
    if(operation=='display'  || operation === undefined)
    {
        console.log(cowsay.say({text: 'Calculator, Author: Daniela Constantin'}));

        var text =  "display\n" + "addition\n" + "subtraction\n" + "division\n" + "multiply\n" + "modulo\n" + "sqrt\n" + "absolute\n" +
        "power\n" + "sort\n" + "reverse\n" + "maximum\n" + "minimum\n" + "unique\n" + "cosinus\n" + "sinus" ;

        console.log(text);
    }

    if(operation=='addition')
    {
        if(vect.length -3 <= 1)
            console.log("ERROR: addition command uses at least 2 parameters");
        else
            if(process.argv[process.argv.length-1]!="complex")
            {
                var sum=0;
                for(let i=3; i<process.argv.length; i++)
                {
                    sum+=parseFloat(process.argv[i]);
                }
                console.log(sum);
            }
            else
            {
                var sum_real=0;
                var sum_imag=0;
                for(let i=3; i<process.argv.length-1; i=i+2)
                {
                    sum_real+=parseFloat(process.argv[i]);
                }
                for(let i=4; i<process.argv.length-1; i=i+2)
                {
                    sum_imag+=parseFloat(process.argv[i]);
                }
                if(sum_real===0)
                    console.log(sum_imag + "i");
                else
                {
                    if(sum_imag<0)
                        console.log(sum_real + "-" + Math.abs(sum_imag) + "i");
                    else if(sum_imag>0)
                        console.log(sum_real + "+" + sum_imag + "i");
                        else if(sum_imag===0)
                            console.log(sum_real);
                }
            }
    }

    if(operation=='subtraction')
    {
        if(vect.length -3 <= 1)
            console.log("ERROR: subtraction command uses at least 2 parameters");
        else
        {
            if(process.argv[process.argv.length-1]!="complex")
            {
                var sub=parseFloat(process.argv[3]);
                for(let i=4; i<process.argv.length; i++)
                {
                    sub-=parseFloat(process.argv[i]);
                }
                console.log(sub);
            }
            else
            {
                var sub_real=process.argv[3];
                var sub_imag=process.argv[4];
                for(let i=5; i<process.argv.length-1; i=i+2)
                {
                    sub_real-=parseFloat(process.argv[i]);
                }
                for(let i=6; i<process.argv.length-1; i=i+2)
                {
                    sub_imag-=parseFloat(process.argv[i]);
                }
                if(sub_real===0)
                    console.log(sub_imag + "i");
                else
                {
                    if(sub_imag<0)
                        console.log(sub_real + "-" + Math.abs(sub_imag) + "i");
                    else if(sub_imag>0)
                        console.log(sub_real + "+" + sub_imag + "i");
                        else if(sub_imag===0)
                            console.log(sub_real);
                }
            }
        }
    }

    if(operation=='multiply')
    {
        if(vect.length -3 <= 1)
            console.log("ERROR: multiply command uses at least 2 parameters");
        else
        {
            if(process.argv[process.argv.length-1]!="complex")
            {
                var product=1;
                for(let i=3; i<process.argv.length; i++)
                {
                    product*=parseFloat(process.argv[i]);
                }
                console.log(product);
            }
            else
            {
                var prod_real=process.argv[3];
                var prod_imag=process.argv[4];
                var pr,pi,cr,ci;
                for(let i=5; i<process.argv.length-1; i=i+2)
                {
                    pr=process.argv[i];
                    pi=process.argv[i+1];
                    cr=prod_real*pr - prod_imag*pi;
                    ci=prod_real*pi + pr*prod_imag;
                    prod_real=cr;
                    prod_imag=ci;
                }
                if(prod_real===0)
                    console.log(prod_imag + "i");
                else
                {
                    if(prod_imag<0)
                        console.log(prod_real + "-" + Math.abs(prod_imag) + "i");
                    else if(prod_imag>0)
                            console.log(prod_real + "+" + prod_imag + "i");
                        else if(prod_imag===0)
                            console.log(prod_real);
                }
            }
        }
    }

    if(operation=='division')
    {
        if(vect.length -3 <= 1)
            console.log("ERROR: division command uses at least 2 parameters");
        else
        {
            var div=parseFloat(process.argv[3]);
            for(let i=4; i<process.argv.length; i++)
            {
                div/=parseFloat(process.argv[i]);
            }
            console.log(div);
        }
    }

    if(operation=='modulo')
    {
        if(vect.length -3 != 2)
            console.log("ERROR: modulo command uses at least 2 parameters");
        else
        {
            var num1=parseFloat(process.argv[3]);
            var num2=parseFloat(process.argv[4]);
            console.log(Math.abs(num1%num2));
        }
    }

    if(operation=='sqrt')
    {
        if(vect.length -3 != 1)
            console.log("ERROR: sqrt command uses at least 1 parameters");
        else
        {
            var num=parseFloat(process.argv[3]);
            console.log(Math.sqrt(num));
        }
    }

    if(operation=='absolute')
    {
        if(vect.length -3 != 1)
            console.log("ERROR: absolute command uses at least 1 parameters");
        else
        {
            var num=parseFloat(process.argv[3]);
            console.log(Math.abs(num));
        }
    }

    if(operation=='power')
    {
        if(vect.length -3 != 2)
            console.log("ERROR: power command uses at least 2 parameters");
        else
        {
            var a=parseFloat(process.argv[3]);
            var b=parseFloat(process.argv[4]);
            console.log(Math.pow(a,b));
        }
    }

    if(operation=='sort')
    {
        if(vect.length -3 === 0)
            console.log("ERROR: sort command uses at least 1 parameters");
        else
        {
            var arr=[], aux;
            for(let i=3; i<process.argv.length; i++)
            {
                arr.push(parseFloat(process.argv[i]));
            }
                
            for(let i=0; i<arr.length-1; i++)
            {
                for(let j=i+1; j<arr.length; j++)
                {
                    if(arr[j]<arr[i])
                    {
                        aux=arr[i];
                        arr[i]=arr[j];
                        arr[j]=aux;
                    }
                }
            }
            for(let i=0;i<arr.length;i++)
            {
                process.stdout.write(arr[i] + " ");
            }
        }
    }

    if(operation=='reverse')
    {
        if(vect.length -3 === 0)
            console.log("ERROR: reverse command uses at least 1 parameters");
        else
        {
            var arr=[], arr_rev=[];
            for(let i=3; i<process.argv.length; i++)
            {
                arr.push(parseFloat(process.argv[i]));
            }

            if(arr.length == 1)
            {
                console.log(arr[0]);
            }
            else
            {
                for(let i=arr.length-1; i>=0; i--)
                {
                    arr_rev.push(arr[i]);
                }

                for(let i=0;i<arr_rev.length;i++)
                {
                    process.stdout.write(arr_rev[i] + " ");
                }
            }
        }
    }

    if(operation=='unique')
    {
        if(vect.length -3 === 0)
            console.log("ERROR: unique command uses at least 1 parameters");
        else
        {
            var arr=[],ok;
            for(let i=3; i<process.argv.length; i++)
            {
                ok=1;
                for(let j=0; j<arr.length; j++)
                {
                    if(arr[j]==process.argv[i])
                        ok=0;
                }
                if(ok==1)
                    arr.push(parseFloat(process.argv[i]));
            }
            if(arr.length == 1)
            {
                console.log(arr[0]);
            }
            else
            {
                for(let i=0;i<arr.length;i++)
                {
                    process.stdout.write(arr[i] + " ");
                }
            }
        }
    }

    if(operation=='maximum')
    {
        if(vect.length -3 === 0)
            console.log("ERROR: maximum command uses at least 1 parameters");
        else
        {
            var max=parseFloat(process.argv[3]);
            for(let i=4; i<process.argv.length; i++)
            {
                if(parseFloat(process.argv[i])>max)
                    max=parseFloat(process.argv[i]);
            }
            console.log(max);
        }
    }

    if(operation=='minimum')
    {
        if(vect.length -3 === 0)
            console.log("ERROR: minimum command uses at least 1 parameters");
        else
        {
            var min=parseFloat(process.argv[3]);
            for(let i=4; i<process.argv.length; i++)
            {
                if(parseFloat(process.argv[i])<min)
                    min=parseFloat(process.argv[i]);
            }
            console.log(min);
        }
    }

    if(operation=='cosinus')
    {
        if(vect.length -3 != 1)
            console.log("ERROR: cosinus command uses exactly 1 parameters");
        else
        {
            var n=parseFloat(process.argv[3]);
            console.log(Math.cos(n));
        }
    }

    if(operation=='sinus')
    {
        if(vect.length -3 != 1)
            console.log("ERROR: sinus command uses exactly 1 parameters");
        else
        {
            var n=parseFloat(process.argv[3]);
            console.log(Math.sin(n));
        }
    }
}